import random as r


def random(stack):
    stack.append(r.random())
