=======
Credits
=======

Maintainer
----------

* Simon Percivall <percivall@gmail.com>

Authors
-------

* The Python Software Foundation
* Bogdan Opanchuk
* Vladimir Iakovlev
* Thomas Grainger
* Amund Hov
* Jakub Wilk
* Mateusz Bysiek
* Serge Sans Paille
